# Air_pollution_prediction
Predicting air Quality for Pollution control using ML model


OBJECTIVE :
 
 1. To predict real-time air pollution levels in urban cities.  
 2. To provide air quality information for the public. 
 3. To identify and provide different categories and levels of pollution in air
 4. To develop more accurate and cost-effective air quality prediction system by using random forest algorithm and AQI.
 
 PROPOSED SYSTEM
 
As we all know air pollution is one of the major problems in urban cities, where the particulate matter is the most dangerous part of air  pollution which effects human than any other substances.
In our project we predict air quality by using Random forest algorithm with air Prediction of air quality for pollution control 
quality index provided by the respected government agencies. Here, we make use of feature analysis for prediction process to provide more effective and general model. Our system considers various data taken for number of hours and days from Bangalore, India. This dataset will be helpful for training the system, later we compute real time datasets for predicting the pollution levels in that city, this predicted information will provide crucial information which will be helpful for pollution control and management. 
